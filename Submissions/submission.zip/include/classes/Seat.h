// include/classes/Seat.h
#ifndef SEAT_H
#define SEAT_H

#include <string>
using std::string;

class Seat {
private:
    int row_number;
    char seat_character;
    string passenger_id;
public:
    Seat(string seat_id, string passenger_id);
    Seat(int row_number, char seat_character, string passenger_id);
    string get_passenger_id() const;
    int get_row_number() const;
    char get_seat_character() const;
};

#endif // SEAT_H

