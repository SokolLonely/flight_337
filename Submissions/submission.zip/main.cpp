// main.cpp
#include <iostream>
#include "include/classes/Airline.h"
#include "include/classes/Flight.h"
#include "include/utils/ui_utils.h"
#include "include/utils/flight_operations.h"
#include "include/utils/data_io.h"
using namespace std;
const string default_airline = "WestJet";

int main() {
    displayHeader();
    int menu_choice;

    // Initialize airline with flights
    Airline* selectedAirline = createAirline(default_airline);

    int selected_flight_index = 0;

    while((menu_choice = menu())) {
        clearScreen();
        Flight& selected_flight = selectedAirline -> get_flight(selected_flight_index);
        switch(menu_choice) {
            case 1:
                selected_flight_index = selectFlight(selectedAirline -> get_flights());
                pressEnter();
                break;
            case 2:
                displaySeatMap(selected_flight);
                pressEnter();
                break;
            case 3:
                displayPassengerInfo(selected_flight);
                pressEnter();
                break;
            case 4:
                addNewPassenger(selected_flight);
                pressEnter();
                break;
            case 5:
                removeExistingPassenger(selected_flight);
                pressEnter();
                break;
            case 6:
                saveData(selectedAirline -> get_flights());
                pressEnter();
                break;
            case 7:
                cout << "Program terminated." << endl;
                delete selectedAirline;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
                pressEnter();
                break;
        }
    }
    delete selectedAirline;
    return 0;   
}